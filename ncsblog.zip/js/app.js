// // console.log('Im in');
// // 'use strict';

// /* App Module */

// angular.module('blogApp', ['ngRoute'])
//   .config(function ( $routeProvider ) {
//     'use strict';
//     // configure urls
//     $routeProvider
//       // inbox route
//       .when('/', {
//         templateUrl: 'index.html',
//         controller: 'blogControllers', // map js to html scope
//       })
//       .when('/blog5', {
//         templateUrl: 'partials/blog5.html',
//         controller: 'CChefCtrls', // map js to html scope
//       })
//       .otherwise({ 
//         redirectTo: '/'
//       });
//   });
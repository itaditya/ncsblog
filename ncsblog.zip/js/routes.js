// blogApp.config(
//     function($routeProvider,$locationProvider) {
//         $locationProvider.hashPrefix('!');
//         $routeProvider
//             .when('/',
//                 {
//                     controller : 'blogControllers' ,
//                     templateUrl : 'index.html'
//                 })
//             .when('/howtogit',
//                 {
//                     controller : 'blogControllers' ,
//                     templateUrl : 'view1.html'
//                 })
//             .otherwise({ redirectTo : '/' });
// });